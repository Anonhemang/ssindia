<!-- Main Footer -->
<footer class="main-footer">
<!-- To the right -->
  <div class="float-right d-none d-sm-inline">
    Anything you want
  </div>
  <!-- Default to the left -->
  <strong>&copy; Copyright Shree Shakti Industries <?php echo date('Y');?> | Designed by <a href="https://www.weblogysphere.com/">weblogysphere</a>.</strong> All rights reserved.
  <!-- Copyright ©2021 All rights reserved | Designed by weblogysphere -->
</footer>
